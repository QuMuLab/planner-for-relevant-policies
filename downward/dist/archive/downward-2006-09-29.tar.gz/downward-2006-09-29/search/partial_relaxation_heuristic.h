#ifndef PARTIAL_RELAXATION_HEURISTIC_H
#define PARTIAL_RELAXATION_HEURISTIC_H

#include "heuristic.h"

class PartialRelaxationHeuristic : public Heuristic {
protected:
    virtual void initialize();
    virtual int compute_heuristic(const State &state);
public:
    PartialRelaxationHeuristic();
    ~PartialRelaxationHeuristic();
};

#endif
