#ifndef OPEN_LIST_H
#define OPEN_LIST_H

#include <deque>
#include <utility>
#include <vector>

class State;
class Operator;

class OpenList {
    typedef std::pair<const State *, const Operator *> Entry;
    typedef std::deque<Entry> Bucket;
    std::vector<Bucket> buckets;
    mutable int lowest_bucket;
    int size;
public:
    OpenList();
    ~OpenList();

    void insert(int key, const State *parent, const Operator *operator_);
    Entry remove_min();
    void clear();

    int min() const;
    bool empty() const;
};

#endif
