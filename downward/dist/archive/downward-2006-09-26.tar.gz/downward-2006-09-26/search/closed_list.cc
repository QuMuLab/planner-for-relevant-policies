#include "closed_list.h"
#include "state.h"

#include <algorithm>
#include <cassert>
using namespace std;

/*
  Map-based implementation of a closed list.
  Might be speeded up by using a hash_map, but then that's
  non-standard and requires defining hash keys.

  The closed list has two purposes:
  1. It stores which nodes have been expanded or scheduled to expand
     already to avoid duplicates (i.e., it is used like a set).
     These states "live" in the closed list -- in particular,
     permanently valid pointers to these states are obtained upon
     insertion.
  2. It can trace back a path from the initial state to a given state
     in the list.
  
  The datatypes used for the closed list could easily be
  parameterized, but there is no such need presently.
*/


ClosedList::ClosedList() {
}

ClosedList::~ClosedList() {
}

const State *ClosedList::insert(const State &state, const State *predecessor,
				const Operator *reached_by) {
    map<State, PredecessorInfo>::iterator it =
	closed.insert(make_pair(state, PredecessorInfo(predecessor, reached_by))).first;
    return &it->first;
}

void ClosedList::clear() {
    closed.clear();
}

bool ClosedList::contains(const State &state) const {
    return closed.count(state) != 0;
}

int ClosedList::size() const {
    return closed.size();
}

void ClosedList::trace_path(const State &state,
			    vector<const Operator *> &path) const {
    assert(path.empty());
    State current_state = state;
    for(;;) {
	const PredecessorInfo &info = closed.find(current_state)->second;
	if(info.predecessor == 0)
	    break;
	path.push_back(info.reached_by);
	current_state = *info.predecessor;
    }

    reverse(path.begin(), path.end());
}
