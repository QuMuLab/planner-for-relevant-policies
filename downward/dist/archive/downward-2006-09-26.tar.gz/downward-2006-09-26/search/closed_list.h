#ifndef CLOSED_LIST_H
#define CLOSED_LIST_H

#include <map>
#include <vector>

class Operator;
class State;

class ClosedList {
    struct PredecessorInfo {
	const State *predecessor;
	const Operator *reached_by;
	PredecessorInfo(const State *pred, const Operator *reached)
	    : predecessor(pred), reached_by(reached) {}
    };
    std::map<State, PredecessorInfo> closed;
public:
    ClosedList();
    ~ClosedList();
    const State *insert(const State &state,
			const State *predecessor,
			const Operator *reached_by);
    void clear();

    bool contains(const State &state) const;
    int size() const;
    void trace_path(const State &state, std::vector<const Operator *> &path) const;
};

#endif
