#include "open_list.h"

#include <cassert>
using namespace std;

/*
  Bucket-based implementation of an open list.
  Nodes with identical heuristic value are expanded in FIFO order.

  It would be easy to templatize the "State *" and "Operator *"
  datatypes, because these are only used as anonymous data. However,
  there is little point in applying such generalizations before there
  is any need for them.
*/

OpenList::OpenList() {
    lowest_bucket = 0;
    size = 0;
}

OpenList::~OpenList() {
}

void OpenList::insert(int key, const State *parent, const Operator *operator_) {
    assert(key >= 0);
    if(key >= buckets.size())
	buckets.resize(key + 1);
    else if(key < lowest_bucket)
	lowest_bucket = key;
    buckets[key].push_back(Entry(parent, operator_));
    size++;
}

int OpenList::min() const {
    assert(size > 0);
    while(buckets[lowest_bucket].empty())
	lowest_bucket++;
    return lowest_bucket;
}

OpenList::Entry OpenList::remove_min() {
    assert(size > 0);
    while(buckets[lowest_bucket].empty())
	lowest_bucket++;
    size--;
    Entry result = buckets[lowest_bucket].front();
    buckets[lowest_bucket].pop_front();
    return result;
}

bool OpenList::empty() const {
    return size == 0;
}

void OpenList::clear() {
    buckets.clear();
    lowest_bucket = 0;
    size = 0;
}

