#ifndef SETCOVER_H
#define SETCOVER_H

#include <vector>

extern std::vector<int> set_cover(const std::vector<std::vector<int> > &input);

#endif

